﻿namespace BEPUphysics.NarrowPhaseSystems.Pairs
{
    /// <summary>
    /// Implemented by detector volume pair handlers with children.
    /// </summary>
    public interface IDetectorVolumePairHandlerParent
    {
    }
}
